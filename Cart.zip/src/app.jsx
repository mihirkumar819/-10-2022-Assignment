import Product1Comp from "./user.component";


function App(){
    return(
        <div>
            <h1 style={{backgroundColor:"lightBlue" ,textAlign:"center",marginTop:"50px"}}>AVENGERS STORE</h1>
            { <Product1Comp/>}
        </div>   
    ) 
};
export default App;      