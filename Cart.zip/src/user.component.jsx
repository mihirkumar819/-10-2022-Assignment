import axios from "axios"
import { useState } from "react";
import { useEffect } from "react"; 
import "./style.css"

let Product1Comp=()=>{

    let [products,setProducts] = useState([]);
    let [qty,getQty] = useState({qty:0});
    let [nproduct,setCart]=useState({_id:'',hero:'',name:'',price:'',instock:true})

    let refresh=()=>{
        axios.get("http://localhost:2050/data").then(res=>{
            setProducts(res.data)
        })
    }
    useEffect(function(){
        refresh();
    },[]);

    let addCart=(pid)=>{
        axios.get("http://localhost:2050/edit/"+pid).then(res => {
            setCart(res.data);
            
        })
    }

    let clickHandler=(evt)=>{
        getQty({...qty, qty : evt.target.value})
    }
    return<div className="main" style={{display:"flex",justifyContent:"center"}}>
         <div className="maincls">   

                

                {
                    products.map((product,idx)=>{
                        return <div className="box">
                                        
                                            <div className="card shadow-sm">
                                                <div className="card-body bg"> 
                                                    Title : {product.hero}
                                                    <br/>
                                                    Price : {product.price}
                                                    <br />
                                                    Quantity <br/>
                                                    <br/>
                                                    <input onInput={(evt)=> clickHandler(evt)} type="number" />
                                                    &nbsp;
                                                    <button  onClick={()=>addCart(product._id)}>ADD TO CART</button>
                                                </div>
                                            </div>
                                       
                                    </div>
                            
                    })
                }
                </div>

     <div className="lower" style={{backgroundColor:"lightblue",justifyContent:"center",width:"700px",height:"700px"}}>
        <h1 style={{fontFamily:"sans-serif" ,padding:"20px",color:"Black"}}>Bill Amount </h1><br /><br />
        <p style={{fontFamily:"sans-serif" ,padding:"20px",color:"Black"}}><b>NAME</b>: {nproduct.hero}</p>
        <p style={{fontFamily:"sans-serif",padding:"20px"}}><b>PRICE</b>: {nproduct.price}</p>
        <p style={{fontFamily:"sans-serif",padding:"20px"}}><b>QTY</b>: {qty.qty}</p>
        <p style={{fontFamily:"sans-serif",padding:"20px"}}><b>TOTAL AMOUNT</b>: {(nproduct.price)*(qty.qty)}</p>
     </div>

            </div>
    

            
}

export default Product1Comp;